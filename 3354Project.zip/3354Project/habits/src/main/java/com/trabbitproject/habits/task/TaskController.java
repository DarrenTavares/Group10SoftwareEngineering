// package com.trabbitproject.habits.task;

// import org.springframework.web.bind.annotation.RestController;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.RequestParam;


// @RestController
// public class TaskController {
//     @GetMapping(value="path")
//     public SomeData getMethodName(@RequestParam String param) {
//         return new SomeData();
//     }
    
    
    
// }
