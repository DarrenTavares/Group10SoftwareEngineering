// package com.trabbitproject.habits.config;

// public class AuthResponse {
//     String token;
//     public AuthResponse(String token) {
//         this.token = token;
//     }


// }
