// package com.trabbitproject.habits.task;

// import org.bson.types.ObjectId;
// import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
// import org.springframework.stereotype.Repository;

// import reactor.core.publisher.Flux;
// import java.time.LocalDateTime;



// @Repository
// public interface TaskRepository extends ReactiveMongoRepository<Task, ObjectId>{
//     Flux<Task>findTaskByDate(LocalDateTime date);
// }
