package com.trabbitproject.habits.config;

import java.beans.JavaBean;
import java.util.ArrayList;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trabbitproject.habits.user.User;
import com.trabbitproject.habits.user.UserRepository;
import com.trabbitproject.habits.user.UserService;

import reactor.core.publisher.Mono;

// @RestController
// @RequestMapping("/api/auth")
// public class AuthController {

//     @Autowired
//     private AuthenticationManager authenticationManager;

//     @Autowired
//     private JWTService jwtUtil;

//     @Autowired
//     private UserRepository userRepository;

//     @Autowired
//     private UserService userDetailsService;

//     @Autowired
//     private PasswordEncoder passwordEncoder; // Inject PasswordEncoder

//     @PostMapping("/login")
//     public Mono<ResponseEntity<AuthResponse>> createAuthenticationToken(@RequestBody AuthRequest authenticationRequest) {
//         return authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword())
//                 .map(authentication -> {
//                     UserDetails userDetails = (UserDetails) authentication.getPrincipal();
//                     String token = jwtUtil.generateToken(userDetails.getUsername());
//                     return ResponseEntity.ok(new AuthResponse(token));
//                 })
//                 .onErrorResume(AuthenticationException.class, error -> Mono.just(ResponseEntity.status(HttpStatus.UNAUTHORIZED).build()));
//     }

//     @PostMapping("/register")
//     public Mono<ResponseEntity<Object>> registerUser(@RequestBody UserRegistrationRequest registrationRequest) {
//         return userRepository.findByUsername(registrationRequest.getUsername())
//                 .flatMap(existingUser -> Mono.just(ResponseEntity.status(HttpStatus.CONFLICT).build()))
//                 .switchIfEmpty(createUserAndGenerateToken(registrationRequest));
//     }

//     private Mono<Authentication> authenticate(String username, String password) {
//         return (Mono<Authentication>) authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
//     }

//     private Mono<? extends ResponseEntity<Object>> createUserAndGenerateToken(UserRegistrationRequest registrationRequest) {
//         User newUser = new User();
//         newUser.setUsername(registrationRequest.getUsername());
//         newUser.setPassword(passwordEncoder.encode(registrationRequest.getPassword())); // Use PasswordEncoder

//         return userRepository.save(newUser)
//                 .map(savedUser -> {
//                     UserDetails userDetails = new User(savedUser.getUsername(), savedUser.getPassword());
//                     String token = jwtUtil.generateToken(userDetails);
//                     return ResponseEntity.ok(new AuthResponse(token));
//                 });
//     }
// }

@RestController
@RequestMapping("/")
public class AuthController {
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/register")
    public Mono<ResponseEntity<String>> registerUser(@RequestBody Map<String, String> registrationRequest) {
        String username = registrationRequest.get("username");
        String password = registrationRequest.get("password");

        if (username == null || password == null) {
            return Mono.just(ResponseEntity.badRequest().body("Username and password are required"));
        }

        return userRepository.findByUsername(username)
                .flatMap(existingUser -> Mono.just(ResponseEntity.badRequest().body("Username already exists")))
                .switchIfEmpty(userRepository.save(createUser(username, password))
                        .map(savedUser -> ResponseEntity.ok("Registration successful"))
                );
}

private User createUser(String username, String password) {
    User newUser = new User();
    newUser.setUsername(username);
    newUser.setPassword(passwordEncoder.encode(password));
    // Set other user details as needed
    return newUser;
}

}
